<div class="tabber">
	<?php 	//Tabbed Content Widget Area
			if ( !function_exists('dynamic_sidebar')
	        || !dynamic_sidebar('Tabbed Content') ) :
	 		endif; 
	?>
</div>