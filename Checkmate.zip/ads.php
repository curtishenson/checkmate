<?php 
	/*
	Whatever you put in this file will be controlled by the Ad(from ads.php) widget!
	This is an easy way to setup a custom ad.  For even more customizing the code that controls this template is in the functions.php line 146
	*/
?>