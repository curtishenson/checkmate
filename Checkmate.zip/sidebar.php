<div class="span-10 last">
	<?php if ( !function_exists('dynamic_sidebar')
			|| !dynamic_sidebar('Sidebar Top') ) : 
	endif; ?>
</div>

<div class="span-5">
	<?php if ( !function_exists('dynamic_sidebar')
	        || !dynamic_sidebar('Sidebar Left') ) : 
	endif; ?>
</div>

<div class="span-5 last">
	<?php if ( !function_exists('dynamic_sidebar')
	        || !dynamic_sidebar('Sidebar Right') ) : 
	endif; ?>
</div>

<div class="span-10 last">
	<?php if ( !function_exists('dynamic_sidebar')
			|| !dynamic_sidebar('Sidebar Bottom') ) : 
	endif; ?>
</div>
	